Twitter clone for Computer Science
==================================

Built with Twitter Bootstrap and lots of code stolen from Twitter.com  

_`For Education Purposes only`_

## Credits
- [Twitter Bootstrap](https://twitter.github.com/bootstrap/)
- [Twitter](http://twitter.com)
- [The Barack Obama Campaign](http://www.barackobama.com/)
- _Put together by:_ [Regis Zaleman](http://www.dalton.org)
- _For:_ [Gordy Campbell](http://www.dalton.org)

## Using
- __Text Editor:__ [Sublime Text 3](http://www.sublimetext.com/3)
- __CSS preprocessing language:__ [LESS](http://lesscss.org/)
- __Build Tool:__ [CodeKit](http://incident57.com/codekit/)